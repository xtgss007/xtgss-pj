<?php
    
    class Conn{
        /**
		 * 数据库连接，请修改成自己的
		 *  host为主机，建议用ip地址，mysql的ip地址
		 * 这里忽略了端口，因为默认为3306，
		 * user为mysql用户名
		 *  db_name 为数据库名
		 *  chartset 为 数据库转换字符集
		 */
         private $_db_config = array(
             'host'=>'localhost',
             'user'=>'root',
             'password'=>'',
             'db_name'=>'test',
             'chartset'=>'utf8'
         );
         
         private function getConn(){
             $conn = mysql_connect($this->_db_config['host'], $this->_db_config['user'], $this->_db_config['password']) ;
             mysql_select_db($this->_db_config['db_name'], $conn); 
             mysql_query("set names ".$this->_db_config['chartset']);
             if(!$conn){
                 die("不能连接数据库");
             } 
             return $conn;
         }
         public function exec($sql){ 
             $conn = $this->getConn();
             mysql_query($sql,$conn);  
         }
         private function find($sql){
             $this->getConn();
             $rs = mysql_query($sql); 
             return $rs;
         }
         public function getAll($sql){   
             $rs = $this->find($sql);  
             $array = $this->source2array($rs,'all'); 
             $this->freeSource($rs);
             return $array;
         }
         public function getOne($sql){
             $rs = $this->find($sql);
             $array = $this->source2array($rs,'one');
             $this->freeSource($rs);
             return $array;
         }
         private function source2array($rs,$type){
             $new_array = array();
             while($row = mysql_fetch_array($rs, MYSQL_ASSOC)){
                if($type == 'one'){ 
                    $new_array = $row;
                    break;
                }else{ 
                    $new_array[] = $row;
                }
             }
             return $new_array;
         }
         private function freeSource($rs){
             mysql_free_result($rs);
             mysql_close();
         }
         public  function commitExec($sqlarray){
             
         }
    }  
?>