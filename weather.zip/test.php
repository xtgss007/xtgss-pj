<?php
header("Content-type:text/xml");
require 'weather.php';
require 'getData.php';
//$param = $_GET['param'] ;
//调用方法。。
//在init函数中注入初始值。
//城市ID我没有在程序做出异常处理，请确保cityId的正确
//weather.php 和XmlAssemble.php文件放在同一目录下 101160101
$weather= new Weather();
echo @$weather->init(getData::getParam())->getXml();
/*返回XML文档如下所示：

<?xml version="1.0" encoding="UTF-8"?><weathers><currentDaysWeather><city>兰州</city><cityid>101160101</cityid><temp>21</temp><WD>西南风</WD><WS>2级</WS><SD>31%</SD><WSE>2</WSE><time>13:30</time><isRadar>1</isRadar><Radar>JC_RADAR_AZ9931_JB</Radar></currentDaysWeather><lastDaysWeather><items><date>24日星期二</date><dayOrNight>白天</dayOrNight><photo></photo><weather>多云</weather><temp>高温 24℃</temp><longWD>无持续风向</longWD><WSE>微风</WSE></items><items><date>24日星期二</date><dayOrNight>夜间</dayOrNight><photo></photo><weather>晴</weather><temp>低温 12℃</temp><longWD>无持续风向</longWD><WSE>微风</WSE></items><items><date>25日星期三</date><dayOrNight>白天</dayOrNight><photo></photo><weather>晴</weather><temp>高温 25℃</temp><longWD>无持续风向</longWD><WSE>微风</WSE></items><items><date>25日星期三</date><dayOrNight>夜间</dayOrNight><photo></photo><weather>阵雨</weather><temp>低温 12℃</temp><longWD>无持续风向</longWD><WSE>微风</WSE></items><items><date>26日星期四</date><dayOrNight>白天</dayOrNight><photo></photo><weather>多云</weather><temp>高温 25℃</temp><longWD>无持续风向</longWD><WSE>微风</WSE></items><items><date>26日星期四</date><dayOrNight>夜间</dayOrNight><photo></photo><weather>多云</weather><temp>低温 12℃</temp><longWD>无持续风向</longWD><WSE>微风</WSE></items><items><date>27日星期五</date><dayOrNight>白天</dayOrNight><photo></photo><weather>晴</weather><temp>高温 29℃</temp><longWD>无持续风向</longWD><WSE>微风</WSE></items><items><date>27日星期五</date><dayOrNight>夜间</dayOrNight><photo></photo><weather>晴</weather><temp>低温 14℃</temp><longWD>无持续风向</longWD><WSE>微风</WSE></items><items><date>28日星期六</date><dayOrNight>白天</dayOrNight><photo></photo><weather>晴</weather><temp>高温 30℃</temp><longWD>无持续风向</longWD><WSE>微风</WSE></items><items><date>28日星期六</date><dayOrNight>夜间</dayOrNight><photo></photo><weather>阵雨</weather><temp>低温 15℃</temp><longWD>无持续风向</longWD><WSE>微风</WSE></items><items><date>29日星期日</date><dayOrNight>白天</dayOrNight><photo></photo><weather>阵雨</weather><temp>高温 27℃</temp><longWD>无持续风向</longWD><WSE>微风</WSE></items><items><date>29日星期日</date><dayOrNight>夜间</dayOrNight><photo></photo><weather>多云</weather><temp>低温 14℃</temp><longWD>无持续风向</longWD><WSE>微风</WSE></items><items><date>30日星期一</date><dayOrNight>白天</dayOrNight><photo></photo><weather>多云</weather><temp>高温 25℃</temp><longWD>无持续风向</longWD><WSE>微风</WSE></items></lastDaysWeather></weathers>

返回的json数据今天没来得及做，以后有空补上。
 
*/
