<?php 
	require 'connection.php';
	/**
	 * 连接数据库，根据用户ip来决定所要显示的天气地区
	 *
	 **/
	 class getData{
		static function getIp(){
			$user_IP = ($_SERVER["HTTP_VIA"]) ? $_SERVER["HTTP_X_FORWARDED_FOR"] : $_SERVER["REMOTE_ADDR"];
			$user_IP = ($user_IP) ? $user_IP : $_SERVER["REMOTE_ADDR"];  
			return $user_IP;
		} 
		static function getParam(){ 
			$user_ip = ip2long(self::getIp()); 
			$sql = "SELECT * FROM temp_city tc LEFT JOIN s_ips s ON s.address LIKE CONCAT('%',tc.detail,'%') WHERE startip <= '".$user_ip."' AND endip >= '".$user_ip."' LIMIT 1";
			$conn = new Conn();
			$rs = $conn->getOne($sql);
			if(count($rs)<1) { 
				$param = '101010100'; //默认为北京天气
			}else{
				$param = $rs['city_no'];
			}
			return $param;
		}
	 }