<?php
    class XA{
        private $_head = '<?xml version="1.0" encoding="UTF-8"?>';
        private $_str = '';
        private $_lastDaysTagLevel1;
        private $_lastDaysTagLevel2;
        private $_lastDaysTagLevel3;
        private $_currentDaysTag = 'currentDaysWeather';

        public function init($obj,$contentArray,$tag){ 
            $this->_str .= $this->_head;
            $this->_str .= "<weathers>";
            $this->AssmbleCurrent($obj);
            $this->Assmble($contentArray,$tag);
            $this->_str .="</weathers>";
            return $this->_str;
        }
        private function Assmble($contentArray,$tag){
            foreach($tag as $key=>$value){
                $this->_lastDaysTagLevel1 = $key;
                foreach ($value as $k=>$var){
                    $this->_lastDaysTagLevel2  = $k;
                    $this->_lastDaysTagLevel3 = $var;
                }
            }
            $this->_str .= '<'.$this->_lastDaysTagLevel1.'>';
            foreach ($contentArray as $key=>$value){ 
                $this->AssmbleLevel1($value);
                $i++;
            }
            $this->_str .= '</'.$this->_lastDaysTagLevel1.'>'; 
        }
        private  function AssmbleLevel1($content){ 
            foreach ($content as $key => $value) {
                $this->_str .= '<'.$this->_lastDaysTagLevel2.'>';
                $this->Assmblelevel2($value);
                $this->_str .= '</'.$this->_lastDaysTagLevel2.'>';
                $j++;
            }
        }
        private function Assmblelevel2($content){
            $k=0;
            foreach ($content as $key=>$value){
                $this->_str .= '<'.$this->_lastDaysTagLevel3[$k].'>';
                $this->_str .= $value;
                $this->_str .= '</'.$this->_lastDaysTagLevel3[$k].'>';
                $k++;
            }
        }
        private function AssmbleCurrent($obj){
            $this->_str .= '<'.$this->_currentDaysTag.'>';
            foreach($obj as $key=>$value){
                $this->_str .= '<'.$key.'>'.$value.'</'.$key.'>';
            }
            $this->_str .= '</'.$this->_currentDaysTag.'>';
        }
    }