<?php 
    /**
     * @author XtGss
     * @time 2011-05-23
     * @deprecated get some date for www.weather.com.cn
     */

     class Weather{
         private $_main_url      = 'http://www.weather.com.cn/weather/${city}.shtml';//101160101
         private $_other_url     = 'http://www.weather.com.cn/data/sk/${city}.html';
         private $_global_reg    = '/<div\s+class="weatherYubaoBox">.*?<\/div>/';
         private $_tables_reg    = '/<\!--day.*?<\/table>/';
         private $_rows_reg      = '/<tr.*?<\/tr>/';
         private $_cols_reg      = '/<td.*?<\/td>/';
         private $_html_clear    = '/<.*?>/';
         private $_array         = array(  "lastDaysWeather"=>array(
                        "items"=>array('date','dayOrNight','photo','weather','temp','longWD','WSE')
                        ) 
               );
         /**
          * 初始化参�?
          * @param <string|number> $city_id
          * @return Weather 
          */
         public function init($city_id){
             $this->_main_url  = str_replace('${city}', $city_id, $this->_main_url);
             $this->_other_url = str_replace('${city}', $city_id, $this->_other_url);
             return $this;
         }
         /**
          * 得到数组
          */
         private  function getArray(){
             $matchs_level_1 = $this->getDivs();
             $matchs_level_2 = array();
             $matchs_level_3 = array();
             $matchs_level_4 = array();
             foreach ($matchs_level_1 as $key => $value){
                 $matchs_level_2[] = $this->getTables($value);
             }
             $matchs_level_2 = $this->arr221($matchs_level_2);
             foreach ($matchs_level_2 as $key => $value){
                 $matchs_level_3[] = $this->getTrs($value);
             }
             foreach($matchs_level_3 as $key=>$value){
                 $matchs_level_4[]=$this->getTds($value);
             }
             //var_dump($matchs_level_4);die();
             return ($matchs_level_4);
         }
         private function arr221($arr2){
             $new_arr2 = array();
             foreach ($arr2 as $key=>$value){
                 foreach($value as $k => $var){
                     $new_arr2[]=$var;
                 }
             }
             return $new_arr2;
         }
         /**
          * 取得网站的内�?
          * @return <string>
          */
         private function getContent(){
             $content = file_get_contents($this->_main_url);
             $content = str_replace("\r","",$content);
             $content = str_replace("\n","",$content);
             return $content;
         }
         /**
          * get weather Date of div
          * @return <array>
          */
         private function getDivs(){
             $matchs = $this->matchs($this->_global_reg,  $this->getContent());
             if(count($matchs)>0){
                 return $matchs[0];
             }
         }
         /**
          * 取得table中的内容
          * @param <string> $content
          * @return <array>
          */
         private function getTables($content){
             $matchs = $this->matchs($this->_tables_reg,  $content);
             if(count($matchs)>0){
                 return $matchs[0];
             }
         }
         /**
          * get matchs <tr>.*?</tr>
          * @param <string> $content
          * @return <array>
          */
         private function getTrs($content){
             $matchs = $this->matchs($this->_rows_reg,$content);
             if(count($matchs)>0){
                 return $matchs[0];
             }
         }
         /**
          * get data for <td>.*?,\/td>
          * @param <array> $arr
          * @return <array>
          */
         private function getTds($arr){ 
             $matchs = array();
             foreach($arr as $key=>$value){
                 $matchs[] = $this->matchs($this->_cols_reg,$value);
             }
             return $this->assembleTds($matchs);
         }
         /**
          * assemble array and cls html code
          * @param <array> $arr
          * @return <array>
          */
         private function assembleTds($array){
             $data = "";
             $new_arr = array();
             $temp = 0;
             //<img src="/m2/i/icon_weather/29x20/n00.gif" />
             $img_regx = '/<img\s+src=".*?\/>/';
             foreach ($array as $key=>$arr){
                 for ($i=0,$length=sizeof($arr);$i<$length;$i++){ 
                        $k = 0;
                         for($j=0,$len=sizeof($arr[$i]);$j<$len;$j++){ 
                             $photo = $this->matchs($img_regx,$arr[$i][$j]);
                             if(count($photo)>0 && count($photo[0])){///m2/i/icon_weather/29x20/
                                 $img = preg_replace("/<img\s+src=\"/","",$photo[0][0]);
                                 $img = preg_replace("/\"\s+\/>/","",$img);
                                 $img = preg_replace('/\/.*\//',"",$img);
                                 $new_arr[$temp][$k] = $this->_link_url.$img; 
                                 $k++;
                                 continue;
                             }
                            $arr[$i][$j] = trim($this->clsHtml($arr[$i][$j])," " );
                            if($temp==0 && $j==0) {
                                $data = $arr[$i][$j];
                                $new_arr[$temp][$k] = $arr[$i][$j];
                            }
                            else {
                                if($j==0){
                                    $new_arr[$temp][$k] = $data;
                                    $k++;
                                }
                                $new_arr[$temp][$k]=$arr[$i][$j];
                            }
                            $k++;
                         } 
                 }
                 $temp++;
             } 
             return $new_arr;
         }

         /**
          * preg_match
          * @param <regx> $pattern
          * @param <string> $subject
          * @return <array>
          */
         private function matchs($pattern, $subject){
             preg_match_all($pattern, $subject, $matches);
             return $matches;
         }
         /**
          * cls  html to ""
          * @param <string> $content
          * @return <string>
          */
         private function clsHtml($content){
             return preg_replace($this->_html_clear,"",$content);
         }
         private function getCurrentObject(){
             $content = file_get_contents($this->_other_url);
             $content = str_replace("\r","",$content);
             $content = str_replace("\n","",$content);
             $Objects  = json_decode($content);
             return $Objects->weatherinfo;
         }
         public function getXml(){
             $array = $this->getArray();
             $obj   = $this->getCurrentObject();
             require 'XmlAssmble.php';
             $xa = new XA();
             $str = $xa->init($obj,$array,$this->_array);
             //echo $str;
             return $str;
         }
         public function getJson(){
             //todo
            /* $array = $this->getArray();
             $obj   = $this->getCurrentObject();
             require 'JsonAssmble.php';
             $ja = new JA();
             $str = $ja->init($obj,$array,$this->_array);
             //echo $str;
//             return $str;
             * */ 
         }
     }